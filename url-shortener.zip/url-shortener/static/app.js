const $ = (id) => document.getElementById(id);
const goBtn = $("go"), errEl = $("error"), resultEl = $("result"), shortEl = $("short");

function showError(msg) { errEl.textContent = msg; errEl.hidden = !msg; }

async function shorten() {
  showError("");
  resultEl.hidden = true;
  goBtn.disabled = true;
  try {
    const res = await fetch("/api/shorten", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: $("url").value, custom_code: $("custom").value }),
    });
    const data = await res.json();
    if (!res.ok) return showError(data.error || "Something went wrong.");
    shortEl.textContent = data.short_url;
    shortEl.href = data.short_url;
    resultEl.hidden = false;
    loadRecent();
  } catch {
    showError("Can't reach the server. Check that it's running.");
  } finally {
    goBtn.disabled = false;
  }
}

async function loadRecent() {
  try {
    const items = await (await fetch("/api/recent")).json();
    const list = $("list");
    list.innerHTML = "";
    if (!items.length) {
      list.innerHTML = '<li class="empty">No links yet. Shorten one above.</li>';
      return;
    }
    for (const it of items) {
      const li = document.createElement("li");
      const clicks = document.createElement("span");
      clicks.className = "clicks";
      clicks.textContent = `${it.clicks} click${it.clicks === 1 ? "" : "s"}`;
      const a = document.createElement("a");
      a.href = it.short_url; a.target = "_blank"; a.rel = "noopener";
      a.textContent = it.short_url;
      const orig = document.createElement("span");
      orig.className = "orig"; orig.textContent = it.original_url;
      li.append(clicks, a, orig);
      list.appendChild(li);
    }
  } catch { /* ignore */ }
}

goBtn.addEventListener("click", shorten);
$("url").addEventListener("keydown", (e) => { if (e.key === "Enter") shorten(); });
$("custom").addEventListener("keydown", (e) => { if (e.key === "Enter") shorten(); });
$("copy").addEventListener("click", async () => {
  await navigator.clipboard.writeText(shortEl.textContent);
  $("copy").textContent = "Copied";
  setTimeout(() => ($("copy").textContent = "Copy"), 1500);
});
loadRecent();
