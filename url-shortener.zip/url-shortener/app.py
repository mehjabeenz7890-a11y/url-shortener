"""Simple URL Shortener - Flask + SQLite."""
import os
import re
import secrets
import sqlite3
import string
from datetime import datetime, timezone
from urllib.parse import urlparse

from flask import Flask, g, jsonify, redirect, render_template, request

app = Flask(__name__)
app.config["DATABASE"] = os.environ.get(
    "DATABASE", os.path.join(os.path.dirname(__file__), "urls.db")
)

ALPHABET = string.ascii_letters + string.digits
CODE_LENGTH = 6
CUSTOM_CODE_RE = re.compile(r"^[A-Za-z0-9_-]{3,32}$")
RESERVED_CODES = {"api", "static", "shorten", "stats", "favicon.ico"}


# ---------- Database helpers ----------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    with sqlite3.connect(app.config["DATABASE"]) as db:
        db.execute(
            """
            CREATE TABLE IF NOT EXISTS urls (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                short_code   TEXT NOT NULL UNIQUE,
                original_url TEXT NOT NULL,
                created_at   TEXT NOT NULL,
                clicks       INTEGER NOT NULL DEFAULT 0
            )
            """
        )
        db.execute("CREATE INDEX IF NOT EXISTS idx_code ON urls(short_code)")


# ---------- Logic ----------
def is_valid_url(url: str) -> bool:
    try:
        parts = urlparse(url)
        parts.port  # raises ValueError if the port is invalid
    except ValueError:
        return False
    return parts.scheme in ("http", "https") and bool(parts.netloc)


def normalize_url(url: str) -> str:
    url = url.strip()
    if url and "://" not in url:
        # "javascript:..." / "mailto:..." etc. are left alone so validation rejects them;
        # "example.com:8080/x" (host:port) still gets https:// prepended.
        if not re.match(r"^[A-Za-z][A-Za-z0-9+.-]*:(?!\d+(/|$))", url):
            url = "https://" + url
    return url


def generate_code(db) -> str:
    for _ in range(10):
        code = "".join(secrets.choice(ALPHABET) for _ in range(CODE_LENGTH))
        if code in RESERVED_CODES:
            continue
        if not db.execute("SELECT 1 FROM urls WHERE short_code = ?", (code,)).fetchone():
            return code
    raise RuntimeError("Could not generate a unique code")


# ---------- Routes ----------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/shorten", methods=["POST"])
def shorten():
    data = request.get_json(silent=True) or {}
    original = normalize_url(str(data.get("url", "")))
    custom = (data.get("custom_code") or "").strip()

    if not original:
        return jsonify(error="Please enter a URL."), 400
    if len(original) > 2048 or not is_valid_url(original):
        return jsonify(error="That doesn't look like a valid http(s) URL."), 400

    db = get_db()

    if custom:
        if not CUSTOM_CODE_RE.match(custom) or custom.lower() in RESERVED_CODES:
            return jsonify(error="Custom code must be 3-32 letters, numbers, _ or - and not reserved."), 400
        if db.execute("SELECT 1 FROM urls WHERE short_code = ?", (custom,)).fetchone():
            return jsonify(error="That custom code is already taken."), 409
        code = custom
    else:
        # Reuse an existing code if this URL was already shortened (auto-generated only)
        row = db.execute(
            "SELECT short_code FROM urls WHERE original_url = ? ORDER BY id LIMIT 1",
            (original,),
        ).fetchone()
        if row:
            code = row["short_code"]
            return jsonify(
                short_code=code,
                short_url=request.host_url + code,
                original_url=original,
            ), 200
        code = generate_code(db)

    try:
        db.execute(
            "INSERT INTO urls (short_code, original_url, created_at) VALUES (?, ?, ?)",
            (code, original, datetime.now(timezone.utc).isoformat()),
        )
        db.commit()
    except sqlite3.IntegrityError:
        return jsonify(error="Code collision, please try again."), 409

    return jsonify(
        short_code=code, short_url=request.host_url + code, original_url=original
    ), 201


@app.route("/api/stats/<code>")
def stats(code):
    row = get_db().execute("SELECT * FROM urls WHERE short_code = ?", (code,)).fetchone()
    if row is None:
        return jsonify(error="Short code not found."), 404
    return jsonify(
        short_code=row["short_code"],
        original_url=row["original_url"],
        created_at=row["created_at"],
        clicks=row["clicks"],
    )


@app.route("/api/recent")
def recent():
    rows = get_db().execute(
        "SELECT short_code, original_url, clicks FROM urls ORDER BY id DESC LIMIT 10"
    ).fetchall()
    return jsonify(
        [
            dict(short_code=r["short_code"], short_url=request.host_url + r["short_code"],
                 original_url=r["original_url"], clicks=r["clicks"])
            for r in rows
        ]
    )


@app.route("/<code>")
def follow(code):
    db = get_db()
    row = db.execute("SELECT original_url FROM urls WHERE short_code = ?", (code,)).fetchone()
    if row is None:
        return render_template("404.html", code=code), 404
    db.execute("UPDATE urls SET clicks = clicks + 1 WHERE short_code = ?", (code,))
    db.commit()
    return redirect(row["original_url"], code=302)


init_db()

if __name__ == "__main__":
    app.run(debug=True, port=5000)
