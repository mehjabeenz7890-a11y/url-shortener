import os, tempfile, unittest
os.environ["DATABASE"] = os.path.join(tempfile.mkdtemp(), "test.db")
from app import app, init_db


class ShortenerTests(unittest.TestCase):
    def setUp(self):
        init_db()
        self.c = app.test_client()

    def test_shorten_and_redirect(self):
        r = self.c.post("/api/shorten", json={"url": "https://example.com/long/path"})
        self.assertEqual(r.status_code, 201)
        code = r.get_json()["short_code"]
        r2 = self.c.get("/" + code)
        self.assertEqual(r2.status_code, 302)
        self.assertEqual(r2.headers["Location"], "https://example.com/long/path")
        self.assertEqual(self.c.get("/api/stats/" + code).get_json()["clicks"], 1)

    def test_invalid_url(self):
        self.assertEqual(self.c.post("/api/shorten", json={"url": "javascript:alert(1)"}).status_code, 400)

    def test_custom_and_duplicate(self):
        self.assertEqual(self.c.post("/api/shorten", json={"url": "example.org", "custom_code": "mine"}).status_code, 201)
        self.assertEqual(self.c.post("/api/shorten", json={"url": "example.net", "custom_code": "mine"}).status_code, 409)

    def test_unknown_code(self):
        self.assertEqual(self.c.get("/nope123").status_code, 404)


if __name__ == "__main__":
    unittest.main()
