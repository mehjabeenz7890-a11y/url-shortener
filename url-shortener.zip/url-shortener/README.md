# Simple URL Shortener (Flask + SQLite)

## Setup
```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## API
| Method | Route | Description |
|---|---|---|
| POST | `/api/shorten` | Body `{"url": "...", "custom_code": "optional"}` -> `{short_code, short_url, original_url}` |
| GET | `/<code>` | 302 redirect to the original URL (404 if unknown) |
| GET | `/api/stats/<code>` | Original URL, created time, click count |
| GET | `/api/recent` | 10 most recent links |

```bash
curl -X POST http://127.0.0.1:5000/api/shorten \
  -H "Content-Type: application/json" -d '{"url":"https://example.com/very/long"}'
```

## Tests
```bash
python test_app.py
```

## Structure
```
url-shortener/
├── app.py            # Flask app, DB, routes
├── templates/        # index.html, 404.html
├── static/           # style.css, app.js
├── test_app.py
├── requirements.txt
└── README.md
```
Database file `urls.db` is created automatically on first run.
